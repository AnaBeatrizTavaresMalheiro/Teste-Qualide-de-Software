from task_manager.task import TaskAtributo


class TaskService:
    def __init__(self, repository):
        self.repository = repository

    def criar_tarefa(self, titulo, descricao, prioridade, prazo):
        # Cria a task (supondo que Task é sua classe de tarefa)
        task = TaskAtributo(None, titulo, descricao, prioridade, prazo)
        # Valida a task (assumindo que Task tem método validar)
        task.validar()
        # Salva via repository
        return self.repository.save(task)

    def listar_todas(self):
        return self.repository.find_all()

    def atualizar_status(self, id, status):
        task = self.repository.find_by_id(id)
        if not task:
            raise ValueError(f"Tarefa com id {id} não encontrada")
        task.status = status
        # Re-salva para atualizar a task armazenada
        return self.repository.save(task)
