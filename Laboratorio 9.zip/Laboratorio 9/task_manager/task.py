from enum import IntEnum, Enum
from datetime import datetime
from typing import Optional

class Priority(IntEnum):
    BAIXA = 1
    MEDIA = 2
    ALTA = 3

class Status(Enum):
    PENDENTE = "pendente"
    EM_PROGRESSO = "em_progresso"
    CONCLUIDA = "concluida"

class TaskAtributo:
    def __init__(
        self,
        id: Optional[int],
        titulo: str,
        descricao: str,
        prioridade: Priority,
        prazo: datetime,
        status: Status = Status.PENDENTE
    ):
        self.id = id
        self.titulo = titulo
        self.descricao = descricao
        self.prioridade = prioridade
        self.prazo = prazo
        self.status = status

    def validar(self):
        if len(self.titulo) < 3:
            raise ValueError("Título deve ter pelo menos 3 caracteres")

    def validar_data(self):
        print(self.prazo)
        print(datetime.now())
        if self.prazo < datetime.now():
            raise ValueError("Prazo não pode ser no passado")
