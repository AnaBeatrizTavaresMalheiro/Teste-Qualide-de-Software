import pytest
from datetime import datetime
from task_manager.repository import TaskRepository
from task_manager.task import TaskAtributo, Priority

def test_save_atribui_id(mocker):
    mock_storage = mocker.Mock()
    repo = TaskRepository(mock_storage)
    task = TaskAtributo(None, "Teste", "Desc", Priority.BAIXA, datetime.now())
    resultado = repo.save(task)
    assert resultado.id == 1
    mock_storage.add.assert_called_once()

def test_save_chama_storage_add(mocker):
    mock_storage = mocker.Mock()
    repo = TaskRepository(mock_storage)
    task = TaskAtributo(None, "Teste", "Desc", Priority.MEDIA, datetime.now())
    repo.save(task)
    mock_storage.add.assert_called_once_with(1, task)

def test_find_by_id_chama_storage_get(mocker):
    mock_storage = mocker.Mock()
    repo = TaskRepository(mock_storage)
    repo.find_by_id(42)
    mock_storage.get.assert_called_once_with(42)

def test_find_all_retorna_lista(mocker):
    mock_storage = mocker.Mock()
    repo = TaskRepository(mock_storage)
    mock_storage.get_all.return_value = ["task1", "task2"]
    resultado = repo.find_all()
    assert resultado == ["task1", "task2"]
    mock_storage.get_all.assert_called_once()
